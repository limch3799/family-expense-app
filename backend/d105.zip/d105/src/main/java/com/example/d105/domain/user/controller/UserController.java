package com.example.d105.domain.user.controller;

import com.example.d105.domain.user.entity.User;  // 이걸 import 해야 함
import com.example.d105.domain.user.repository.UserRepository;
import com.example.d105.ssafy.service.SsafyApiService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class UserController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final SsafyApiService ssafyApiService;
    @Operation(
            summary = "임시 회원가입",
            description = "임시 회원가입입니다."

    )
    @PostMapping("/signup")
    public void signup(@RequestBody User user) {  // entity.User 사용
        String userKey = ssafyApiService.getMemberWithCode(user.getEmail()).getUserKey();
        System.out.println("userKey : "+userKey);
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setUserKey(userKey);
        user.setCreatedAt(String.valueOf(System.currentTimeMillis()));
        user.setUpdatedAt(String.valueOf(System.currentTimeMillis()));
        userRepository.save(user);
    }
}
