package com.example.d105.domain.transaction.entity;
import com.example.d105.domain.account.entity.UserCard;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "card_transactions", schema = "d105")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CardTransaction {

    @Id
    @Column(name = "transaction_id")
    private Long transactionId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transaction_id")
    private Transaction transaction;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "card_id", insertable = false, updatable = false)
    private UserCard userCard;

    @Column(name = "merchant_name", nullable = false, length = 100)
    private String merchantName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id", insertable = false, updatable = false)
    private Category category;



}
