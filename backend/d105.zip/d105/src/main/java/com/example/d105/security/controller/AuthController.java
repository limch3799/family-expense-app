package com.example.d105.security.controller;

import com.example.d105.security.dto.login.LoginRequestDTO;
import com.example.d105.security.dto.login.LoginResponseDTO;
import com.example.d105.security.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @Operation(
            summary = "사용자 로그인",
            description = "사용자의 이메일과 비밀번호를 받아 인증 후 JWT access token을 발급합니다.현재 userKey 암호화를 진행하지 않은채 userKey 유효성을 판단하고 있으며, 추후 회원가입 기능 완료 시 수정 예정",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "로그인 성공",
                            content = @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = LoginResponseDTO.class)
                            )
                    ),
                    @ApiResponse(
                            responseCode = "401",
                            description = "이메일 또는 비밀번호가 잘못됨"
                    )
            }
    )
    @PostMapping("/login")
    public ResponseEntity<LoginResponseDTO> login (@Valid @RequestBody LoginRequestDTO loginRequest){



        LoginResponseDTO response = authService.login(loginRequest);

        return ResponseEntity.ok(response);
    }
    @Operation(
            summary = "사용자 로그아웃",
            description = "로그아웃을 진행합니다. 백에서는 별도의 처리 없음. 프론트 토큰 삭제"
       
    )
    @PostMapping("/logout")
    public ResponseEntity<String> logout(){
        //해당 토믄 redis에 저장하여 블랙리스트 등록
        return ResponseEntity.ok("로그아웃 되었습니다");
    }
}
