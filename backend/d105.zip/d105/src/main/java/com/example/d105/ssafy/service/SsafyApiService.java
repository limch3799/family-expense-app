package com.example.d105.ssafy.service;

import com.example.d105.ssafy.clinet.SsafyApiClient;
import com.example.d105.ssafy.dto.response.SsafyMemberResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class SsafyApiService {

    private final SsafyApiClient ssafyApiClient;


    public SsafyMemberResponse getMemberWithCode(String email){
        return ssafyApiClient.getMember(email);
    }

    public SsafyMemberResponse getSearchWithCode(String email){
        return ssafyApiClient.getSearch(email);
    }
}
