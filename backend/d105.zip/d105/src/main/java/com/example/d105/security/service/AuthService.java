package com.example.d105.security.service;

import com.example.d105.domain.user.entity.User;
import com.example.d105.domain.user.repository.UserRepository;
import com.example.d105.security.dto.CustomUserDetails;
import com.example.d105.security.dto.login.LoginRequestDTO;
import com.example.d105.security.dto.login.LoginResponseDTO;
import com.example.d105.security.util.JWTUtil;
import com.example.d105.ssafy.service.SsafyApiService;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class AuthService {

    private final AuthenticationManager authenticationManager;
    private final JWTUtil jwtUtil;
    private final UserRepository userRepository;
    private final SsafyApiService ssafyApiService;


    @Transactional
    public LoginResponseDTO login(LoginRequestDTO loginRequest){

        try{

            //인증 처리
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            loginRequest.getEmail(),
                            loginRequest.getPassword()
                    )
            );



            User user = ((CustomUserDetails) authentication.getPrincipal()).getUser();

            System.out.println(user.getUserKey());
            String userKey = ssafyApiService.getSearchWithCode(user.getEmail()).getUserKey();
            if(!user.getUserKey().equals(userKey)){
                new RuntimeException("userKey가 일치하지 않습니다.");
            }
            //JWT 토큰 생성
            String accessToken = jwtUtil.createToken(user.getEmail());

            return LoginResponseDTO.builder()
                    .accessToken(accessToken)
                    .userId(user.getUserId())
                    .build();

        }catch (AuthenticationException e) {
            e.printStackTrace();
            throw  new RuntimeException("이메일 또는 비밀번호가 잘못되었습니다.");
        }
    }


}
