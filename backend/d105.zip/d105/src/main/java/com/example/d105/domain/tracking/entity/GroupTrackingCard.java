package com.example.d105.domain.tracking.entity;

import com.example.d105.domain.account.entity.UserCard;
import com.example.d105.domain.group.entity.GroupMember;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "group_tracking_cards", schema = "d105",
        uniqueConstraints = @UniqueConstraint(columnNames = {"member_id", "card_id"}))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GroupTrackingCard {

    @Id
    @Column(name = "tracking_id")
    private Long trackingId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "member_id", insertable = false, updatable = false)
    private GroupMember member;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "card_id", insertable = false, updatable = false)
    private UserCard card;

    @Column(name = "is_connected", nullable = false)
    private Boolean isConnected ;

}
