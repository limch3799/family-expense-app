package com.example.d105.ssafy.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SsafyMemberRequest {

    private String userId;
    private String apiKey;

}
