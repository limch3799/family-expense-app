//package com.example.d105.domain.group.service;
//
//import org.springframework.stereotype.Service;
//
//@Service
//public class GroupService {
//
//    private final SecureRandom secureRandom = new SecureRandom();
//
//    //초대코드 생성하기
//    public String generateUniqueInviteCode(){
//
//        String inviteCode;
//        int attempts = 0;
//
//        do{
//
//        }
//    }
//
//    private String generateHashBasedCode() {
//        try {
//            // 고유한 데이터 조합
//            String uniqueData = System.currentTimeMillis() +
//                    "-" + System.nanoTime() +
//                    "-" + secureRandom.nextLong() +
//                    "-" + Thread.currentThread().getId();
//
//            MessageDigest digest = MessageDigest.getInstance("SHA-256");
//            byte[] hash = digest.digest(uniqueData.getBytes(StandardCharsets.UTF_8));
//
//            // Base62 인코딩 (더 짧고 URL 안전)
//            String encoded = Base62.encode(hash);
//
//            // 100글자 이내로 자르기
//            int length = Math.min(encoded.length(), 100);
//            return encoded.substring(0, length);
//
//        } catch (NoSuchAlgorithmException e) {
//            throw new RuntimeException("해시 알고리즘을 찾을 수 없습니다", e);
//        }
//    }
//}
