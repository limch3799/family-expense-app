package com.example.d105.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
@RequestMapping("/api/v1/test")
public class TestController {

    @GetMapping("/")
    public String sample(){
        return "sample!!";
    }
}
