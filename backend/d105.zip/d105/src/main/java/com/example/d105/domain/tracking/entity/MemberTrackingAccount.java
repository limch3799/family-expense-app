package com.example.d105.domain.tracking.entity;
import com.example.d105.domain.account.entity.UserAccount;
import com.example.d105.domain.group.entity.GroupMember;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "member_tracking_accounts", schema = "d105",
        uniqueConstraints = @UniqueConstraint(columnNames = {"member_id", "account_id"}))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MemberTrackingAccount {

    @Id
    @Column(name = "tracking_id")
    private Long trackingId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "member_id", insertable = false, updatable = false)
    private GroupMember member;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "account_id", insertable = false, updatable = false)
    private UserAccount account;

    @Column(name = "is_connected", nullable = false)
    private Boolean isConnected ;

}
