package com.example.d105;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class D105Application {

	public static void main(String[] args) {
		SpringApplication.run(D105Application.class, args);
	}

}
